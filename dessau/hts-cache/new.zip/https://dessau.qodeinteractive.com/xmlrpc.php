<!DOCTYPE html>
<html lang="en-US">
<head>
<meta property="og:url" content="https://dessau.qodeinteractive.com/xmlrpc.php" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Dessau" />
<meta property="og:description" content="A Contemporary Theme for Architects and Interior Designers" />
<meta property="og:image" content="https://dessau.qodeinteractive.com/wp-content/uploads/2019/04/open_graph.jpg" />
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
<title>Page not found &#8211; Dessau</title>
<meta name='robots' content='max-image-preview:large' />

<script data-cfasync="false" data-pagespeed-no-defer>
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
</script>
<link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//static.zdassets.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Dessau &raquo; Feed" href="https://dessau.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dessau &raquo; Comments Feed" href="https://dessau.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/dessau.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://dessau.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-vendors-style-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=8.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=8.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='classic-theme-styles-css' href='https://dessau.qodeinteractive.com/wp-includes/css/classic-themes.min.css?ver=1' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='titan-adminbar-styles-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/anti-spam/assets/css/admin-bar.css?ver=7.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.6.4' type='text/css' media='all' />
<link rel='stylesheet' id='rabbit_css-css' href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=6.1.1' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='ppress-frontend-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/css/frontend.min.css?ver=4.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-flatpickr-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.css?ver=4.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-select2-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-default-style-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/style.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-modules-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/modules.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-dripicons-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/dripicons/dripicons.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_elegant-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/elegant-icons/style.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_awesome-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-ion_icons-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/ion-icons/css/ionicons.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linea_icons-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/linea-icons/style.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linear_icons-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/linear-icons/style.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-simple_line_icons-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://dessau.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://dessau.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-woo-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/woocommerce.min.css?ver=6.1.1' type='text/css' media='all' />
<style id='dessau-select-woo-inline-css' type='text/css'>
.error404 .qodef-content .qodef-content-inner > .qodef-container > .qodef-container-inner, .error404 .qodef-content .qodef-content-inner > .qodef-full-width > .qodef-full-width-inner { padding: 140px 0px 76px 0px;}.error404 .qodef-content .qodef-content-inner > .qodef-container > .qodef-container-inner, .error404 .qodef-content .qodef-content-inner > .qodef-full-width > .qodef-full-width-inner { padding: 140px 0px 76px 0px;}
</style>
<link rel='stylesheet' id='dessau-select-woo-responsive-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/woocommerce-responsive.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-style-dynamic-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/style_dynamic.css?ver=1669374589' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-modules-responsive-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/modules-responsive.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-style-dynamic-responsive-css' href='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/css/style_dynamic_responsive.css?ver=1669374589' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-select-google-fonts-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A200%2C300%2C400%2C500%2C600%2C700%7CRaleway%3A200%2C300%2C400%2C500%2C600%2C700&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='dessau-core-dashboard-style-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/core-dashboard/assets/css/core-dashboard.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='qode-zendesk-chat-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css?ver=6.1.1' type='text/css' media='all' />
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.6.7' async id='tp-tools-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.6.7' async id='revmin-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.7.1.0' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/dessau.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=7.1.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.js?ver=4.3.2' id='ppress-flatpickr-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.js?ver=4.3.2' id='ppress-select2-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.10.0' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://dessau.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://dessau.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://dessau.qodeinteractive.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.1.1" />
<meta name="generator" content="WooCommerce 7.1.0" />


<script data-cfasync="false" data-pagespeed-no-defer>
	var dataLayer_content = {"pagePostType":"404-error"};
	dataLayer.push( dataLayer_content );
</script>
<script data-cfasync="false">
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M4XZBMN');
</script>

 <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<meta name="generator" content="Powered by Slider Revolution 6.6.7 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://dessau.qodeinteractive.com/wp-content/uploads/2018/06/favicon-select.png" sizes="32x32" />
<link rel="icon" href="https://dessau.qodeinteractive.com/wp-content/uploads/2018/06/favicon-select.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://dessau.qodeinteractive.com/wp-content/uploads/2018/06/favicon-select.png" />
<meta name="msapplication-TileImage" content="https://dessau.qodeinteractive.com/wp-content/uploads/2018/06/favicon-select.png" />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
<style type="text/css" id="wp-custom-css">
			.qodef-title-holder.qodef-bg-parallax {
    background-size: cover;
}
.qodef-parallax-row-holder {
    background-size: cover;
}		</style>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 theme-dessau dessau-core-1.2.3 woocommerce-no-js dessau-ver-1.7 qodef-grid-1200 qodef-wide-dropdown-menu-in-grid qodef-dark-header qodef-sticky-header-on-scroll-down-up qodef-dropdown-animate-height qodef-header-standard qodef-menu-area-shadow-disable qodef-menu-area-in-grid-shadow-disable qodef-menu-area-border-disable qodef-menu-area-in-grid-border-disable qodef-logo-area-border-disable qodef-header-vertical-shadow-disable qodef-header-vertical-border-disable qodef-side-menu-slide-from-right qodef-woocommerce-columns-3 qodef-woo-normal-space qodef-woo-pl-info-below-image qodef-woo-single-thumb-below-image qodef-woo-single-has-pretty-photo qodef-default-mobile-header qodef-sticky-up-mobile-header qodef-search-covers-header wpb-js-composer js-comp-ver-6.10.0 vc_responsive" itemscope itemtype="http://schema.org/WebPage">
<section class="qodef-side-menu">
<a class="qodef-close-side-menu qodef-close-side-menu-svg-path" href="#">
<svg version="1.1" class="qodef-close-icon" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="19.676px" height="19.507px" viewBox="-0.01 -0.187 19.676 19.507" enable-background="new -0.01 -0.187 19.676 19.507" xml:space="preserve">
<line class="qodef-close-bar-1" fill="none" stroke="#000000" stroke-miterlimit="10" x1="1.401" y1="1.046" x2="18.582" y2="18.144" />
<line class="qodef-close-bar-2" fill="none" stroke="#000000" stroke-miterlimit="10" x1="18.787" y1="0.702" x2="0.869" y2="18.431" />
</svg> </a>
<div id="text-5" class="widget qodef-sidearea widget_text"><div class="qodef-widget-title-holder"><h6 class="qodef-widget-title">Weiss Architecture Studio</h6></div> <div class="textwidget"><p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae lorem.</p>
</div>
</div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-style: solid;margin-top: 15px;margin-bottom: 0px"></div>
</div>
</div><div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
<div class="qodef-separator" style="border-color: rgba(0,0,0,0.1);border-style: solid;width: 100%;border-bottom-width: 1px;margin-top: 9px;margin-bottom: 25px"></div>
</div>
</div><div class="widget qodef-social-icons-group-widget text-align-center"> <a class="qodef-social-icon-widget-holder qodef-icon-has-hover" data-hover-color="#cfcfcf" style="color: #858585;;font-size: 14px;margin: 0px 6px 0px 6px;" href="https://www.facebook.com/QodeInteractive/" target="_blank">
<span class="qodef-social-icon-widget social_facebook"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" data-hover-color="#cfcfcf" style="color: #858585;;font-size: 14px;margin: 0px 6px 0px 6px;" href="https://www.instagram.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget social_instagram"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" data-hover-color="#cfcfcf" style="color: #858585;;font-size: 14px;margin: 0px 6px 0px 6px;" href="https://www.pinterest.com/qodeinteractive/" target="_blank">
<span class="qodef-social-icon-widget social_pinterest"></span> </a>
<a class="qodef-social-icon-widget-holder qodef-icon-has-hover" data-hover-color="#cfcfcf" style="color: #858585;;font-size: 14px;margin: 0px 6px 0px 6px;" href="https://twitter.com/QodeInteractive" target="_blank">
<span class="qodef-social-icon-widget social_twitter"></span> </a>
</div></section>
<div class="qodef-wrapper">
<div class="qodef-wrapper-inner">
<header class="qodef-page-header">
<div class="qodef-menu-area qodef-menu-center">
<div class="qodef-grid">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<div class="qodef-logo-wrapper">
<a itemprop="url" href="https://dessau.qodeinteractive.com/" style="height: 11px;">
<img itemprop="image" class="qodef-normal-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo.png" width="124" height="23" alt="logo" />
<img itemprop="image" class="qodef-dark-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo.png" width="124" height="23" alt="dark logo" /> <img itemprop="image" class="qodef-light-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo_white.png" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<nav class="qodef-main-menu qodef-drop-down qodef-default-nav">
<ul id="menu-main-menu-navigation" class="clearfix"><li id="nav-menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Home</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-606" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://dessau.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Main Home</span></span></a></li>
<li id="nav-menu-item-1302" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architecture-studio/" class=""><span class="item_outer"><span class="item_text">Architecture Studio</span></span></a></li>
<li id="nav-menu-item-2091" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-masonry/" class=""><span class="item_outer"><span class="item_text">Portfolio Masonry</span></span></a></li>
<li id="nav-menu-item-1538" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/uncovering-projects/" class=""><span class="item_outer"><span class="item_text">Uncovering Projects</span></span></a></li>
<li id="nav-menu-item-1863" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/category-columns/" class=""><span class="item_outer"><span class="item_text">Category Columns</span></span></a></li>
<li id="nav-menu-item-605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/metro-showcase/" class=""><span class="item_outer"><span class="item_text">Metro Showcase</span></span></a></li>
<li id="nav-menu-item-1722" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/interior-design/" class=""><span class="item_outer"><span class="item_text">Interior Design</span></span></a></li>
<li id="nav-menu-item-2186" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-metro/" class=""><span class="item_outer"><span class="item_text">Portfolio Metro</span></span></a></li>
<li id="nav-menu-item-3104" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/decor-studio/" class=""><span class="item_outer"><span class="item_text">Décor Studio</span></span></a></li>
<li id="nav-menu-item-2344" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architect-portfolio/" class=""><span class="item_outer"><span class="item_text">Architect Portfolio</span></span></a></li>
<li id="nav-menu-item-1470" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/fullscreen-projects/" class=""><span class="item_outer"><span class="item_text">Fullscreen Projects</span></span></a></li>
<li id="nav-menu-item-1903" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/project-gallery/" class=""><span class="item_outer"><span class="item_text">Project Gallery</span></span></a></li>
<li id="nav-menu-item-3578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/horizontal-showcase/" class=""><span class="item_outer"><span class="item_text">Horizontal Showcase</span></span></a></li>
<li id="nav-menu-item-3674" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1032" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
<li id="nav-menu-item-849" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-me/" class=""><span class="item_outer"><span class="item_text">About Me</span></span></a></li>
<li id="nav-menu-item-677" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/meet-the-team/" class=""><span class="item_outer"><span class="item_text">Meet The Team</span></span></a></li>
<li id="nav-menu-item-1122" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-studio/" class=""><span class="item_outer"><span class="item_text">Our Studio</span></span></a></li>
<li id="nav-menu-item-2575" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-offices/" class=""><span class="item_outer"><span class="item_text">Our Offices</span></span></a></li>
<li id="nav-menu-item-3921" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_text">What We Offer</span></span></a></li>
<li id="nav-menu-item-2573" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/services-pricing/" class=""><span class="item_outer"><span class="item_text">Services &#038; Pricing</span></span></a></li>
<li id="nav-menu-item-1031" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span></span></a></li>
<li id="nav-menu-item-1576" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">Faq Page</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-13" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Portfolio</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-679" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Portfolio Types</span></span></a>
<ul>
<li id="nav-menu-item-1918" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard/" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-2727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery/" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-2728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-joined/" class=""><span class="item_outer"><span class="item_text">Gallery Joined</span></span></a></li>
<li id="nav-menu-item-2731" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/pinterest/" class=""><span class="item_outer"><span class="item_text">Pinterest</span></span></a></li>
<li id="nav-menu-item-2729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry/" class=""><span class="item_outer"><span class="item_text">Masonry</span></span></a></li>
<li id="nav-menu-item-2730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry-joined/" class=""><span class="item_outer"><span class="item_text">Masonry Joined</span></span></a></li>
<li id="nav-menu-item-2746" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/scattered/" class=""><span class="item_outer"><span class="item_text">Scattered</span></span></a></li>
<li id="nav-menu-item-2749" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/motion-gallery/" class=""><span class="item_outer"><span class="item_text">Motion Gallery</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-220" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Columns</span></span></a>
<ul>
<li id="nav-menu-item-2813" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/two-columns/" class=""><span class="item_outer"><span class="item_text">Two Columns</span></span></a></li>
<li id="nav-menu-item-2812" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span></span></a></li>
<li id="nav-menu-item-2807" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns-wide/" class=""><span class="item_outer"><span class="item_text">Three Columns Wide</span></span></a></li>
<li id="nav-menu-item-2811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span></span></a></li>
<li id="nav-menu-item-2818" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns-wide/" class=""><span class="item_outer"><span class="item_text">Four Columns Wide</span></span></a></li>
<li id="nav-menu-item-2810" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns/" class=""><span class="item_outer"><span class="item_text">Five Columns</span></span></a></li>
<li id="nav-menu-item-2809" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns-wide/" class=""><span class="item_outer"><span class="item_text">Five Columns Wide</span></span></a></li>
<li id="nav-menu-item-2808" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/six-columns-wide/" class=""><span class="item_outer"><span class="item_text">Six Columns Wide</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Hover Types</span></span></a>
<ul>
<li id="nav-menu-item-3546" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-lift/" class=""><span class="item_outer"><span class="item_text">Lift</span></span></a></li>
<li id="nav-menu-item-3545" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-trim/" class=""><span class="item_outer"><span class="item_text">Trim</span></span></a></li>
<li id="nav-menu-item-3594" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-overlay/" class=""><span class="item_outer"><span class="item_text">Overlay</span></span></a></li>
<li id="nav-menu-item-3601" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-simple-overlay/" class=""><span class="item_outer"><span class="item_text">Simple Overlay</span></span></a></li>
<li id="nav-menu-item-3608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-slide-up/" class=""><span class="item_outer"><span class="item_text">Slide Up</span></span></a></li>
<li id="nav-menu-item-3605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-center-cross/" class=""><span class="item_outer"><span class="item_text">Center Cross</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Single</span></span></a>
<ul>
<li id="nav-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/art-museum/" class=""><span class="item_outer"><span class="item_text">Portfolio Showcase</span></span></a></li>
<li id="nav-menu-item-523" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/white-apartment/" class=""><span class="item_outer"><span class="item_text">Masonry</span></span></a></li>
<li id="nav-menu-item-522" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/office-design/" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-521" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/campbell-pavillion/" class=""><span class="item_outer"><span class="item_text">Small Gallery</span></span></a></li>
<li id="nav-menu-item-519" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/wooden-house/" class=""><span class="item_outer"><span class="item_text">Big Images</span></span></a></li>
<li id="nav-menu-item-517" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/modern-apartment/" class=""><span class="item_outer"><span class="item_text">Small Images</span></span></a></li>
<li id="nav-menu-item-520" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/c37-office/" class=""><span class="item_outer"><span class="item_text">Big Slider</span></span></a></li>
<li id="nav-menu-item-518" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/minimalist-kitchen/" class=""><span class="item_outer"><span class="item_text">Small Slider</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-14" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-720" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span></span></a></li>
<li id="nav-menu-item-726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span></span></a></li>
<li id="nav-menu-item-725" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-without-sidebar/" class=""><span class="item_outer"><span class="item_text">Without Sidebar</span></span></a></li>
<li id="nav-menu-item-729" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Post Types</span></span></a>
<ul>
<li id="nav-menu-item-730" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/bauhaus/" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-731" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/minimalism/" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-732" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/famous-architects/" class=""><span class="item_outer"><span class="item_text">Link</span></span></a></li>
<li id="nav-menu-item-733" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/modern-architecture/" class=""><span class="item_outer"><span class="item_text">Quote</span></span></a></li>
<li id="nav-menu-item-734" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/scandinavian-house/" class=""><span class="item_outer"><span class="item_text">Video</span></span></a></li>
<li id="nav-menu-item-735" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/home-offices/" class=""><span class="item_outer"><span class="item_text">Audio</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/" class=""><span class="item_outer"><span class="item_text">Product List</span></span></a></li>
<li id="nav-menu-item-1958" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://dessau.qodeinteractive.com/product/stool/" class=""><span class="item_outer"><span class="item_text">Product Single</span></span></a></li>
<li id="nav-menu-item-1960" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Layouts</span></span></a>
<ul>
<li id="nav-menu-item-1998" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span></span></a></li>
<li id="nav-menu-item-2577" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span></span></a></li>
<li id="nav-menu-item-2578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/full-width/" class=""><span class="item_outer"><span class="item_text">Full Width</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1727" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span></span></a>
<ul>
<li id="nav-menu-item-1729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My Account</span></span></a></li>
<li id="nav-menu-item-1730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span></span></a></li>
<li id="nav-menu-item-1728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-16" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Elements</span><i class="qodef-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1182" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Classic</span></span></a>
<ul>
<li id="nav-menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/accordions/" class=""><span class="item_outer"><span class="item_text">Accordions</span></span></a></li>
<li id="nav-menu-item-3151" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span></span></a></li>
<li id="nav-menu-item-3150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span></span></a></li>
<li id="nav-menu-item-1181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span></span></a></li>
<li id="nav-menu-item-3149" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon with Text</span></span></a></li>
<li id="nav-menu-item-3336" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1185" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Interactive</span></span></a>
<ul>
<li id="nav-menu-item-3181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/testimonials/" class=""><span class="item_outer"><span class="item_text">Testimonials</span></span></a></li>
<li id="nav-menu-item-3155" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span></span></a></li>
<li id="nav-menu-item-3154" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/parallax-section/" class=""><span class="item_outer"><span class="item_text">Parallax Section</span></span></a></li>
<li id="nav-menu-item-3163" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span></span></a></li>
<li id="nav-menu-item-3153" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/shop-list/" class=""><span class="item_outer"><span class="item_text">Shop List</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1183" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Infographic</span></span></a>
<ul>
<li id="nav-menu-item-1723" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/image-info-section/" class=""><span class="item_outer"><span class="item_text">Image Info Section</span></span></a></li>
<li id="nav-menu-item-3174" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pricing-tables/" class=""><span class="item_outer"><span class="item_text">Pricing Tables</span></span></a></li>
<li id="nav-menu-item-3175" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span></span></a></li>
<li id="nav-menu-item-3165" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/counters-countdown/" class=""><span class="item_outer"><span class="item_text">Counters &#038; Countdown</span></span></a></li>
<li id="nav-menu-item-3173" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pie-chart/" class=""><span class="item_outer"><span class="item_text">Pie Chart</span></span></a></li>
<li id="nav-menu-item-3168" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1184" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Typography</span></span></a>
<ul>
<li id="nav-menu-item-3169" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span></span></a></li>
<li id="nav-menu-item-3164" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span></span></a></li>
<li id="nav-menu-item-3176" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/section-title/" class=""><span class="item_outer"><span class="item_text">Section Title</span></span></a></li>
<li id="nav-menu-item-3162" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span></span></a></li>
<li id="nav-menu-item-3167" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/dropcaps-highlights/" class=""><span class="item_outer"><span class="item_text">Dropcaps &#038; Highlights</span></span></a></li>
<li id="nav-menu-item-3177" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span></span></a></li>
<li id="nav-menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<a class="qodef-side-menu-button-opener qodef-icon-has-hover qodef-side-menu-button-opener-svg-path" href="javascript:void(0)">
<span class="qodef-side-menu-icon">
<svg class="qodef-burger" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="29.996px" height="10.999px" viewBox="0 0 29.996 10.999" enable-background="new 0 0 29.996 10.999" xml:space="preserve">
<rect class="qodef-burger-bar-1" width="29.996" height="0.969" />
<rect class="qodef-burger-bar-2" y="5.015" width="29.996" height="0.969" />
<rect class="qodef-burger-bar-3" y="10.03" width="29.996" height="0.969" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
</div>
<div class="qodef-sticky-header">
<div class="qodef-sticky-holder qodef-menu-center">
<div class="qodef-grid">
<div class="qodef-vertical-align-containers">
<div class="qodef-position-left"><div class="qodef-position-left-inner">
<div class="qodef-logo-wrapper">
<a itemprop="url" href="https://dessau.qodeinteractive.com/" style="height: 11px;">
<img itemprop="image" class="qodef-normal-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo.png" width="124" height="23" alt="logo" />
<img itemprop="image" class="qodef-dark-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo.png" width="124" height="23" alt="dark logo" /> <img itemprop="image" class="qodef-light-logo" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo_white.png" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<nav class="qodef-main-menu qodef-drop-down qodef-sticky-nav">
<ul id="menu-main-menu-navigation-1" class="clearfix"><li id="sticky-nav-menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Home</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-606" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://dessau.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Main Home</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1302" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architecture-studio/" class=""><span class="item_outer"><span class="item_text">Architecture Studio</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2091" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-masonry/" class=""><span class="item_outer"><span class="item_text">Portfolio Masonry</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1538" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/uncovering-projects/" class=""><span class="item_outer"><span class="item_text">Uncovering Projects</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1863" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/category-columns/" class=""><span class="item_outer"><span class="item_text">Category Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/metro-showcase/" class=""><span class="item_outer"><span class="item_text">Metro Showcase</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1722" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/interior-design/" class=""><span class="item_outer"><span class="item_text">Interior Design</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2186" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-metro/" class=""><span class="item_outer"><span class="item_text">Portfolio Metro</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3104" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/decor-studio/" class=""><span class="item_outer"><span class="item_text">Décor Studio</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2344" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architect-portfolio/" class=""><span class="item_outer"><span class="item_text">Architect Portfolio</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1470" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/fullscreen-projects/" class=""><span class="item_outer"><span class="item_text">Fullscreen Projects</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1903" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/project-gallery/" class=""><span class="item_outer"><span class="item_text">Project Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/horizontal-showcase/" class=""><span class="item_outer"><span class="item_text">Horizontal Showcase</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3674" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-1032" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-849" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-me/" class=""><span class="item_outer"><span class="item_text">About Me</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-677" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/meet-the-team/" class=""><span class="item_outer"><span class="item_text">Meet The Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1122" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-studio/" class=""><span class="item_outer"><span class="item_text">Our Studio</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2575" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-offices/" class=""><span class="item_outer"><span class="item_text">Our Offices</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3921" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/what-we-offer/" class=""><span class="item_outer"><span class="item_text">What We Offer</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2573" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/services-pricing/" class=""><span class="item_outer"><span class="item_text">Services &#038; Pricing</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1031" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1576" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">Faq Page</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-13" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Portfolio</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-679" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Portfolio Types</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1918" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard/" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery/" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-joined/" class=""><span class="item_outer"><span class="item_text">Gallery Joined</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2731" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/pinterest/" class=""><span class="item_outer"><span class="item_text">Pinterest</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry/" class=""><span class="item_outer"><span class="item_text">Masonry</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry-joined/" class=""><span class="item_outer"><span class="item_text">Masonry Joined</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2746" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/scattered/" class=""><span class="item_outer"><span class="item_text">Scattered</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2749" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/motion-gallery/" class=""><span class="item_outer"><span class="item_text">Motion Gallery</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-220" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Columns</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-2813" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/two-columns/" class=""><span class="item_outer"><span class="item_text">Two Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2812" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2807" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns-wide/" class=""><span class="item_outer"><span class="item_text">Three Columns Wide</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2818" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns-wide/" class=""><span class="item_outer"><span class="item_text">Four Columns Wide</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2810" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns/" class=""><span class="item_outer"><span class="item_text">Five Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2809" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns-wide/" class=""><span class="item_outer"><span class="item_text">Five Columns Wide</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2808" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/six-columns-wide/" class=""><span class="item_outer"><span class="item_text">Six Columns Wide</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Hover Types</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-3546" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-lift/" class=""><span class="item_outer"><span class="item_text">Lift</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3545" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-trim/" class=""><span class="item_outer"><span class="item_text">Trim</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3594" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-overlay/" class=""><span class="item_outer"><span class="item_text">Overlay</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3601" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-simple-overlay/" class=""><span class="item_outer"><span class="item_text">Simple Overlay</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-slide-up/" class=""><span class="item_outer"><span class="item_text">Slide Up</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-center-cross/" class=""><span class="item_outer"><span class="item_text">Center Cross</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Single</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/art-museum/" class=""><span class="item_outer"><span class="item_text">Portfolio Showcase</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-523" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/white-apartment/" class=""><span class="item_outer"><span class="item_text">Masonry</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-522" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/office-design/" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-521" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/campbell-pavillion/" class=""><span class="item_outer"><span class="item_text">Small Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-519" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/wooden-house/" class=""><span class="item_outer"><span class="item_text">Big Images</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-517" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/modern-apartment/" class=""><span class="item_outer"><span class="item_text">Small Images</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-520" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/c37-office/" class=""><span class="item_outer"><span class="item_text">Big Slider</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-518" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/minimalist-kitchen/" class=""><span class="item_outer"><span class="item_text">Small Slider</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-14" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-720" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-725" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-without-sidebar/" class=""><span class="item_outer"><span class="item_text">Without Sidebar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-729" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Post Types</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-730" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/bauhaus/" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-731" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/minimalism/" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-732" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/famous-architects/" class=""><span class="item_outer"><span class="item_text">Link</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-733" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/modern-architecture/" class=""><span class="item_outer"><span class="item_text">Quote</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-734" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/scandinavian-house/" class=""><span class="item_outer"><span class="item_text">Video</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-735" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/home-offices/" class=""><span class="item_outer"><span class="item_text">Audio</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-1726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/" class=""><span class="item_outer"><span class="item_text">Product List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1958" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://dessau.qodeinteractive.com/product/stool/" class=""><span class="item_outer"><span class="item_text">Product Single</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1960" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Layouts</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1998" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2577" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-2578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/full-width/" class=""><span class="item_outer"><span class="item_text">Full Width</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1727" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop Pages</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My Account</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-16" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Elements</span><span class="plus"></span><i class="qodef-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="sticky-nav-menu-item-1182" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Classic</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/accordions/" class=""><span class="item_outer"><span class="item_text">Accordions</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3151" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/tabs/" class=""><span class="item_outer"><span class="item_text">Tabs</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/clients/" class=""><span class="item_outer"><span class="item_text">Clients</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-1181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/buttons/" class=""><span class="item_outer"><span class="item_text">Buttons</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3149" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/icon-with-text/" class=""><span class="item_outer"><span class="item_text">Icon with Text</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3336" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/contact-form/" class=""><span class="item_outer"><span class="item_text">Contact Form</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1185" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Interactive</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-3181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/testimonials/" class=""><span class="item_outer"><span class="item_text">Testimonials</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3155" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/team/" class=""><span class="item_outer"><span class="item_text">Team</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3154" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/parallax-section/" class=""><span class="item_outer"><span class="item_text">Parallax Section</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3163" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blog-list/" class=""><span class="item_outer"><span class="item_text">Blog List</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3153" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/shop-list/" class=""><span class="item_outer"><span class="item_text">Shop List</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1183" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Infographic</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-1723" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/image-info-section/" class=""><span class="item_outer"><span class="item_text">Image Info Section</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3174" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pricing-tables/" class=""><span class="item_outer"><span class="item_text">Pricing Tables</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3175" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/progress-bar/" class=""><span class="item_outer"><span class="item_text">Progress Bar</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3165" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/counters-countdown/" class=""><span class="item_outer"><span class="item_text">Counters &#038; Countdown</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3173" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pie-chart/" class=""><span class="item_outer"><span class="item_text">Pie Chart</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3168" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/google-maps/" class=""><span class="item_outer"><span class="item_text">Google Maps</span><span class="plus"></span></span></a></li>
</ul>
</li>
<li id="sticky-nav-menu-item-1184" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Typography</span><span class="plus"></span></span></a>
<ul>
<li id="sticky-nav-menu-item-3169" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/headings/" class=""><span class="item_outer"><span class="item_text">Headings</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3164" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/columns/" class=""><span class="item_outer"><span class="item_text">Columns</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3176" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/section-title/" class=""><span class="item_outer"><span class="item_text">Section Title</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3162" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blockquote/" class=""><span class="item_outer"><span class="item_text">Blockquote</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3167" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/dropcaps-highlights/" class=""><span class="item_outer"><span class="item_text">Dropcaps &#038; Highlights</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3177" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/separators/" class=""><span class="item_outer"><span class="item_text">Separators</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/custom-font/" class=""><span class="item_outer"><span class="item_text">Custom Font</span><span class="plus"></span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul></nav>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
<a class="qodef-side-menu-button-opener qodef-icon-has-hover qodef-side-menu-button-opener-svg-path" href="javascript:void(0)">
<span class="qodef-side-menu-icon">
<svg class="qodef-burger" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="29.996px" height="10.999px" viewBox="0 0 29.996 10.999" enable-background="new 0 0 29.996 10.999" xml:space="preserve">
<rect class="qodef-burger-bar-1" width="29.996" height="0.969" />
<rect class="qodef-burger-bar-2" y="5.015" width="29.996" height="0.969" />
<rect class="qodef-burger-bar-3" y="10.03" width="29.996" height="0.969" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<form action="https://dessau.qodeinteractive.com/" class="qodef-search-cover" method="get">
<div class="qodef-container">
<div class="qodef-container-inner clearfix">
<div class="qodef-form-holder-outer">
<div class="qodef-form-holder">
<div class="qodef-form-holder-inner">
<input type="text" placeholder="Search" name="s" class="qodef_search_field" autocomplete="off" />
<a class="qodef-search-close qodef-search-close-svg-path" href="#">
<svg version="1.1" class="qodef-close-icon" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="19.676px" height="19.507px" viewBox="-0.01 -0.187 19.676 19.507" enable-background="new -0.01 -0.187 19.676 19.507" xml:space="preserve">
<line class="qodef-close-bar-1" fill="none" stroke="#000000" stroke-miterlimit="10" x1="1.401" y1="1.046" x2="18.582" y2="18.144" />
<line class="qodef-close-bar-2" fill="none" stroke="#000000" stroke-miterlimit="10" x1="18.787" y1="0.702" x2="0.869" y2="18.431" />
</svg> </a>
</div>
</div>
</div>
</div>
</div>
</form></header>
<header class="qodef-mobile-header">
<div class="qodef-mobile-header-inner">
<div class="qodef-mobile-header-holder">
<div class="qodef-grid">
<div class="qodef-vertical-align-containers">
<div class="qodef-vertical-align-containers">
<div class="qodef-mobile-menu-opener qodef-mobile-menu-opener-icon-pack">
<a href="javascript:void(0)">
<span class="qodef-mobile-menu-icon">
<span aria-hidden="true" class="qodef-icon-font-elegant icon_menu "></span> </span>
</a>
</div>
<div class="qodef-position-center"><div class="qodef-position-center-inner">
<div class="qodef-mobile-logo-wrapper">
<a itemprop="url" href="https://dessau.qodeinteractive.com/" style="height: 11px">
<img itemprop="image" src="https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/img/logo.png" width="124" height="23" alt="Mobile Logo" />
</a>
</div>
</div>
</div>
<div class="qodef-position-right"><div class="qodef-position-right-inner">
</div>
</div>
</div>
</div>
</div>
</div>
<nav class="qodef-mobile-nav">
<div class="qodef-grid">
<ul id="menu-main-menu-navigation-2" class=""><li id="mobile-menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Home</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-606" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://dessau.qodeinteractive.com/" class=""><span>Main Home</span></a></li>
<li id="mobile-menu-item-1302" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architecture-studio/" class=""><span>Architecture Studio</span></a></li>
<li id="mobile-menu-item-2091" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-masonry/" class=""><span>Portfolio Masonry</span></a></li>
<li id="mobile-menu-item-1538" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/uncovering-projects/" class=""><span>Uncovering Projects</span></a></li>
<li id="mobile-menu-item-1863" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/category-columns/" class=""><span>Category Columns</span></a></li>
<li id="mobile-menu-item-605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/metro-showcase/" class=""><span>Metro Showcase</span></a></li>
<li id="mobile-menu-item-1722" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/interior-design/" class=""><span>Interior Design</span></a></li>
<li id="mobile-menu-item-2186" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio-metro/" class=""><span>Portfolio Metro</span></a></li>
<li id="mobile-menu-item-3104" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/decor-studio/" class=""><span>Décor Studio</span></a></li>
<li id="mobile-menu-item-2344" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/architect-portfolio/" class=""><span>Architect Portfolio</span></a></li>
<li id="mobile-menu-item-1470" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/fullscreen-projects/" class=""><span>Fullscreen Projects</span></a></li>
<li id="mobile-menu-item-1903" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/project-gallery/" class=""><span>Project Gallery</span></a></li>
<li id="mobile-menu-item-3578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/horizontal-showcase/" class=""><span>Horizontal Showcase</span></a></li>
<li id="mobile-menu-item-3674" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/landing/" class=""><span>Landing</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Pages</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1032" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
<li id="mobile-menu-item-849" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/about-me/" class=""><span>About Me</span></a></li>
<li id="mobile-menu-item-677" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/meet-the-team/" class=""><span>Meet The Team</span></a></li>
<li id="mobile-menu-item-1122" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-studio/" class=""><span>Our Studio</span></a></li>
<li id="mobile-menu-item-2575" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/our-offices/" class=""><span>Our Offices</span></a></li>
<li id="mobile-menu-item-3921" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/what-we-offer/" class=""><span>What We Offer</span></a></li>
<li id="mobile-menu-item-2573" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/services-pricing/" class=""><span>Services &#038; Pricing</span></a></li>
<li id="mobile-menu-item-1031" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/contact-us/" class=""><span>Contact Us</span></a></li>
<li id="mobile-menu-item-1576" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/faq-page/" class=""><span>Faq Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-13" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Portfolio</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-679" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Portfolio Types</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1918" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard/" class=""><span>Standard</span></a></li>
<li id="mobile-menu-item-2727" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery/" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-2728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-joined/" class=""><span>Gallery Joined</span></a></li>
<li id="mobile-menu-item-2731" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/pinterest/" class=""><span>Pinterest</span></a></li>
<li id="mobile-menu-item-2729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry/" class=""><span>Masonry</span></a></li>
<li id="mobile-menu-item-2730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/masonry-joined/" class=""><span>Masonry Joined</span></a></li>
<li id="mobile-menu-item-2746" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/scattered/" class=""><span>Scattered</span></a></li>
<li id="mobile-menu-item-2749" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/motion-gallery/" class=""><span>Motion Gallery</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-220" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Columns</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2813" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/two-columns/" class=""><span>Two Columns</span></a></li>
<li id="mobile-menu-item-2812" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns/" class=""><span>Three Columns</span></a></li>
<li id="mobile-menu-item-2807" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/three-columns-wide/" class=""><span>Three Columns Wide</span></a></li>
<li id="mobile-menu-item-2811" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns/" class=""><span>Four Columns</span></a></li>
<li id="mobile-menu-item-2818" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/four-columns-wide/" class=""><span>Four Columns Wide</span></a></li>
<li id="mobile-menu-item-2810" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns/" class=""><span>Five Columns</span></a></li>
<li id="mobile-menu-item-2809" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/five-columns-wide/" class=""><span>Five Columns Wide</span></a></li>
<li id="mobile-menu-item-2808" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/six-columns-wide/" class=""><span>Six Columns Wide</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Hover Types</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-3546" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-lift/" class=""><span>Lift</span></a></li>
<li id="mobile-menu-item-3545" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/standard-trim/" class=""><span>Trim</span></a></li>
<li id="mobile-menu-item-3594" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-overlay/" class=""><span>Overlay</span></a></li>
<li id="mobile-menu-item-3601" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-simple-overlay/" class=""><span>Simple Overlay</span></a></li>
<li id="mobile-menu-item-3608" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-slide-up/" class=""><span>Slide Up</span></a></li>
<li id="mobile-menu-item-3605" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/portfolio/gallery-center-cross/" class=""><span>Center Cross</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-209" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Single</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-757" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/art-museum/" class=""><span>Portfolio Showcase</span></a></li>
<li id="mobile-menu-item-523" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/white-apartment/" class=""><span>Masonry</span></a></li>
<li id="mobile-menu-item-522" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/office-design/" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-521" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/campbell-pavillion/" class=""><span>Small Gallery</span></a></li>
<li id="mobile-menu-item-519" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/wooden-house/" class=""><span>Big Images</span></a></li>
<li id="mobile-menu-item-517" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/modern-apartment/" class=""><span>Small Images</span></a></li>
<li id="mobile-menu-item-520" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/c37-office/" class=""><span>Big Slider</span></a></li>
<li id="mobile-menu-item-518" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://dessau.qodeinteractive.com/portfolio-item/minimalist-kitchen/" class=""><span>Small Slider</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-14" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Blog</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-720" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-right-sidebar/" class=""><span>Right Sidebar</span></a></li>
<li id="mobile-menu-item-726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-left-sidebar/" class=""><span>Left Sidebar</span></a></li>
<li id="mobile-menu-item-725" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/blog/standard-without-sidebar/" class=""><span>Without Sidebar</span></a></li>
<li id="mobile-menu-item-729" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Post Types</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-730" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/bauhaus/" class=""><span>Standard</span></a></li>
<li id="mobile-menu-item-731" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/minimalism/" class=""><span>Gallery</span></a></li>
<li id="mobile-menu-item-732" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/famous-architects/" class=""><span>Link</span></a></li>
<li id="mobile-menu-item-733" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/modern-architecture/" class=""><span>Quote</span></a></li>
<li id="mobile-menu-item-734" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/scandinavian-house/" class=""><span>Video</span></a></li>
<li id="mobile-menu-item-735" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://dessau.qodeinteractive.com/home-offices/" class=""><span>Audio</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1726" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/" class=""><span>Product List</span></a></li>
<li id="mobile-menu-item-1958" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://dessau.qodeinteractive.com/product/stool/" class=""><span>Product Single</span></a></li>
<li id="mobile-menu-item-1960" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop Layouts</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1998" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/three-columns/" class=""><span>Three Columns</span></a></li>
<li id="mobile-menu-item-2577" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/four-columns/" class=""><span>Four Columns</span></a></li>
<li id="mobile-menu-item-2578" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/product-list/full-width/" class=""><span>Full Width</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1727" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Shop Pages</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1729" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/my-account/" class=""><span>My Account</span></a></li>
<li id="mobile-menu-item-1730" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/cart/" class=""><span>Cart</span></a></li>
<li id="mobile-menu-item-1728" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/checkout/" class=""><span>Checkout</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-16" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Elements</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1182" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Classic</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/accordions/" class=""><span>Accordions</span></a></li>
<li id="mobile-menu-item-3151" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/tabs/" class=""><span>Tabs</span></a></li>
<li id="mobile-menu-item-3150" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/clients/" class=""><span>Clients</span></a></li>
<li id="mobile-menu-item-1181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/buttons/" class=""><span>Buttons</span></a></li>
<li id="mobile-menu-item-3149" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/icon-with-text/" class=""><span>Icon with Text</span></a></li>
<li id="mobile-menu-item-3336" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/contact-form/" class=""><span>Contact Form</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1185" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Interactive</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-3181" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/testimonials/" class=""><span>Testimonials</span></a></li>
<li id="mobile-menu-item-3155" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/team/" class=""><span>Team</span></a></li>
<li id="mobile-menu-item-3154" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/parallax-section/" class=""><span>Parallax Section</span></a></li>
<li id="mobile-menu-item-3163" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blog-list/" class=""><span>Blog List</span></a></li>
<li id="mobile-menu-item-3153" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/shop-list/" class=""><span>Shop List</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1183" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Infographic</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1723" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/image-info-section/" class=""><span>Image Info Section</span></a></li>
<li id="mobile-menu-item-3174" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pricing-tables/" class=""><span>Pricing Tables</span></a></li>
<li id="mobile-menu-item-3175" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/progress-bar/" class=""><span>Progress Bar</span></a></li>
<li id="mobile-menu-item-3165" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/counters-countdown/" class=""><span>Counters &#038; Countdown</span></a></li>
<li id="mobile-menu-item-3173" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/pie-chart/" class=""><span>Pie Chart</span></a></li>
<li id="mobile-menu-item-3168" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/google-maps/" class=""><span>Google Maps</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1184" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Typography</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow lnr lnr-chevron-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
<li id="mobile-menu-item-3169" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/headings/" class=""><span>Headings</span></a></li>
<li id="mobile-menu-item-3164" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/columns/" class=""><span>Columns</span></a></li>
<li id="mobile-menu-item-3176" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/section-title/" class=""><span>Section Title</span></a></li>
<li id="mobile-menu-item-3162" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/blockquote/" class=""><span>Blockquote</span></a></li>
<li id="mobile-menu-item-3167" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/dropcaps-highlights/" class=""><span>Dropcaps &#038; Highlights</span></a></li>
<li id="mobile-menu-item-3177" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/separators/" class=""><span>Separators</span></a></li>
<li id="mobile-menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://dessau.qodeinteractive.com/elements/custom-font/" class=""><span>Custom Font</span></a></li>
</ul>
</li>
</ul>
</li>
</ul> </div>
</nav>
</div>
<form action="https://dessau.qodeinteractive.com/" class="qodef-search-cover" method="get">
<div class="qodef-container">
<div class="qodef-container-inner clearfix">
<div class="qodef-form-holder-outer">
<div class="qodef-form-holder">
<div class="qodef-form-holder-inner">
<input type="text" placeholder="Search" name="s" class="qodef_search_field" autocomplete="off" />
<a class="qodef-search-close qodef-search-close-svg-path" href="#">
<svg version="1.1" class="qodef-close-icon" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="19.676px" height="19.507px" viewBox="-0.01 -0.187 19.676 19.507" enable-background="new -0.01 -0.187 19.676 19.507" xml:space="preserve">
<line class="qodef-close-bar-1" fill="none" stroke="#000000" stroke-miterlimit="10" x1="1.401" y1="1.046" x2="18.582" y2="18.144" />
<line class="qodef-close-bar-2" fill="none" stroke="#000000" stroke-miterlimit="10" x1="18.787" y1="0.702" x2="0.869" y2="18.431" />
</svg> </a>
</div>
</div>
</div>
</div>
</div>
</form></header>
<a id='qodef-back-to-top' href='#'>
<span class="qodef-icon-stack">
<span aria-hidden="true" class="qodef-icon-linear-icons lnr lnr-chevron-up "></span> </span>
</a>
<div class="qodef-content" style="margin-top: -100px">
<div class="qodef-content-inner"> <div class="qodef-page-not-found">
<h1 class="qodef-404-title">
404 </h1>
<h3 class="qodef-404-subtitle">
Page not found </h3>
<p class="qodef-404-text">
Oops! The page you are looking for does not exist. It might have been moved or deleted. </p>
<a itemprop="url" href="https://dessau.qodeinteractive.com/" target="_self" class="qodef-btn qodef-btn-medium qodef-btn-solid"> <span class="qodef-btn-text">Back to home</span> </a> </div>
</div>
</div>
</div>
</div>
<script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = false;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
<div class="rbt-toolbar" data-theme="Dessau" data-featured="" data-button-position="80%" data-button-horizontal="right" data-button-alt="no"></div>


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M4XZBMN" height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe></noscript>
 <script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
<link rel='stylesheet' id='rs-plugin-settings-css' href='https://dessau.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.6.7' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.6.4' id='swv-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/dessau.qodeinteractive.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.6.4' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=6.1.1' id='rabbit_js-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.7.1.0' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=7.1.0' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_bf3c66374df90e5506b26f61af34086f","fragment_name":"wc_fragments_bf3c66374df90e5506b26f61af34086f","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=7.1.0' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='ppress-frontend-script-js-extra'>
/* <![CDATA[ */
var pp_ajax_form = {"ajaxurl":"https:\/\/dessau.qodeinteractive.com\/wp-admin\/admin-ajax.php","confirm_delete":"Are you sure?","deleting_text":"Deleting...","deleting_error":"An error occurred. Please try again.","nonce":"4291208a53","disable_ajax_form":"false","is_checkout":"0","is_checkout_tax_enabled":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/js/frontend.min.js?ver=4.3.2' id='ppress-frontend-script-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.16.2' id='gtm4wp-form-move-tracker-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.2' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.13.2' id='jquery-ui-accordion-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.1.1' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.1.1' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.appear.js?ver=6.1.1' id='appear-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/modernizr.min.js?ver=6.1.1' id='modernizr-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.hoverIntent.min.js?ver=6.1.1' id='hoverintent-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.plugin.js?ver=6.1.1' id='jquery-plugin-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/owl.carousel.min.js?ver=6.1.1' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.waypoints.min.js?ver=6.1.1' id='waypoints-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/fluidvids.min.js?ver=6.1.1' id='fluidvids-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/prettyphoto/js/jquery.prettyPhoto.min.js?ver=6.10.0' id='prettyphoto-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=6.1.1' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=6.1.1' id='scrolltoplugin-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/parallax.min.js?ver=6.1.1' id='parallax-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.waitforimages.js?ver=6.1.1' id='waitforimages-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.easing.1.3.js?ver=6.1.1' id='jquery-easing-1.3-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.10.0' id='isotope-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/packery-mode.pkgd.min.js?ver=6.1.1' id='packery-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/jquery.geocomplete.min.js?ver=6.1.1' id='geocomplete-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules/plugins/swiper.min.js?ver=6.1.1' id='swiper-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/countdown/assets/js/plugins/jquery.countdown.min.js?ver=6.1.1' id='countdown-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/counter/assets/js/plugins/counter.js?ver=6.1.1' id='counter-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/counter/assets/js/plugins/absoluteCounter.min.js?ver=6.1.1' id='absoluteCounter-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/custom-font/assets/js/plugins/typed.js?ver=6.1.1' id='typed-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/full-screen-sections/assets/js/plugins/jquery.fullPage.min.js?ver=6.1.1' id='fullPage-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/pie-chart/assets/js/plugins/easypiechart.js?ver=6.1.1' id='easypiechart-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/uncovering-sections/assets/js/plugins/curtain.js?ver=6.1.1' id='curtain-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/dessau-core/shortcodes/vertical-split-slider/assets/js/plugins/jquery.multiscroll.min.js?ver=6.1.1' id='multiscroll-js'></script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3-wc.7.1.0' id='select2-js'></script>
<script type='text/javascript' src='//maps.googleapis.com/maps/api/js?key=AIzaSyDIhoLILE_aRseUc9rsLEx3H6NGVZ_g7b4&#038;ver=6.1.1' id='dessau-select-google-map-api-js'></script>
<script type='text/javascript' id='dessau-select-modules-js-extra'>
/* <![CDATA[ */
var qodefGlobalVars = {"vars":{"qodefAddForAdminBar":0,"qodefElementAppearAmount":-100,"qodefAjaxUrl":"https:\/\/dessau.qodeinteractive.com\/wp-admin\/admin-ajax.php","qodefStickyHeaderHeight":0,"qodefStickyHeaderTransparencyHeight":70,"qodefTopBarHeight":0,"qodefLogoAreaHeight":0,"qodefMenuAreaHeight":100,"qodefMobileHeaderHeight":70}};
var qodefPerPageVars = {"vars":{"qodefMobileHeaderHeight":70,"qodefStickyScrollAmount":275,"qodefHeaderTransparencyHeight":0,"qodefHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type='text/javascript' src='https://dessau.qodeinteractive.com/wp-content/themes/dessau/assets/js/modules.js?ver=6.1.1' id='dessau-select-modules-js'></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&#038;ver=6.1.1" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no" && window.innerWidth > 1024) {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script></body>
</html>